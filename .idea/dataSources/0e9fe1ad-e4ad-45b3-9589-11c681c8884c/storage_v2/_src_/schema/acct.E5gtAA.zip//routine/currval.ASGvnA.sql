create function currval(v_seq_name varchar(50)) returns int
begin  
    declare value integer;  
    set value = 0;  
    select current_val into value  from sequence where seq_name = v_seq_name;  
   return value;  
end;

