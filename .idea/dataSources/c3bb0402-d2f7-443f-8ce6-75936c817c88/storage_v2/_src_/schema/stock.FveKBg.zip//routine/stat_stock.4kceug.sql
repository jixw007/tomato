create function stat_stock(stockCode char(100), stockYear char(100)) returns int
BEGIN
	DECLARE
		temp_up INTEGER default 0;

DECLARE
	temp_down INTEGER default 0;

DECLARE
	temp INTEGER default 0;

SELECT
	(sum(CLOSE) - sum(preclose)) INTO temp_up
FROM
	a_day_data
WHERE
	CODE = stockCode
AND DATE_FORMAT(date, '%Y') = stockYear 
AND CLOSE > preclose;

SELECT
	(sum(preclose) - sum(CLOSE)) into temp_down
FROM
	a_day_data
WHERE
	CODE = stockCode
AND DATE_FORMAT(date, '%Y') = stockYear 
AND CLOSE < preclose;

SELECT
	(temp_up - temp_down) INTO temp;

RETURN temp;


END;

